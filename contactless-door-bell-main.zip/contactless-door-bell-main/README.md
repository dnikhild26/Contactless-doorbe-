<img width="1250" alt="simulation" src="https://github.com/Sanil-Surve/contactless-door-bell/assets/83599854/3ac1672b-4434-43b2-a78b-cfeb431715f1">

In this Project We have created Contactless Doorbell using Arduino UNO, Ultrasonic Sensor, Servo Motor
